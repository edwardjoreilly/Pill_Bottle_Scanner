# Imports
from flask import Flask, render_template, request, session, redirect, url_for, flash
import sys
import time
import psycopg2
import psycopg2.extras
import re
from functions import *
from werkzeug.security import generate_password_hash, check_password_hash
from flask_mail import Mail
from flask_mail import Message
import secrets


app = Flask(__name__)



# Elephant SQL connection

connection = psycopg2.connect(POSTGRESQL_URI)


app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465

app.config['MAIL_USERNAME'] = email_address

app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
mail = Mail(app)


#form:  {secret_key1 : [id,timestamps], secret_key2 : ...}
pass_recovery = {}
#pass_recovery["123456"] = 1 #for testing

# Create users table
try:
	with connection:
		with connection.cursor() as cursor:
			cursor.execute("CREATE TABLE users (id SERIAL PRIMARY KEY, firstname VARCHAR (100) NOT NULL, lastname VARCHAR (100) NOT NULL, username VARCHAR (50) NOT NULL, password VARCHAR (255) NOT NULL, email VARCHAR (50) NOT NULL, securityq1 VARCHAR (50) NOT NULL, securityq2 VARCHAR (50) NOT NULL);")
except psycopg2.errors.DuplicateTable:
	pass

# Create posts table
try:
	with connection:
		with connection.cursor() as cursor:
			cursor.execute("CREATE TABLE posts (id SERIAL PRIMARY KEY, user_name VARCHAR (50) NOT NULL, content VARCHAR (100) NOT NULL);")
except psycopg2.errors.DuplicateTable:
	pass



### Web pages and FUnctions ###

# Homepage
@app.route('/', methods=["GET", "POST"])
def home():
	# Connect to db
	cursor = connection.cursor(cursor_factory=psycopg2.extras.DictCursor)

	# Check if user is loggedin
	if 'loggedin' in session:

		# Display user's previous entries
		cursor.execute('SELECT * FROM posts WHERE user_name = %s', (session['username'],))
		posts = cursor.fetchall()

		# User is loggedin show them the home page
		return render_template('home.html', firstname=session['firstname'], posts=posts)
		
	# User is not loggedin redirect to login page
	return redirect(url_for('login'))



# Function to add posts using OpenCV and PaddleOCR functions from functions.py file
@app.route("/add", methods=["GET", "POST"])
def add():

	errorCheck = False
	# Connect to db
	cursor = connection.cursor(cursor_factory=psycopg2.extras.DictCursor)

	# Get pic of Prescription or text
	try:
		getPic() # OpenCV function in functions.py
	except:
		flash("Please reconnect webcam.")
		errorCheck = True
	
	# Translate picture to text
	try:
		list = getPrescription() # PaddleOCR function in functions.py
	except:
		flash("Error occured please try again.")
		errorCheck = True

	# Convert list of text elements into a String
	string1 = ""
	
	try:
		for l in list:
			string1 += (l + "||||")
	except:
		flash("Error occured please try again.")
		errorCheck = True

	if errorCheck == False:
		# Assign username field in users table to user_name field in posts
		session['user_name'] = session['username']
		user_name = session['username']

		# Create new post for specified user in posts db
		cursor.execute("INSERT INTO posts (user_name, content) VALUES (%s,%s)", (user_name, string1))
		connection.commit()

	# Reload the Homepage
	return redirect(url_for('home'))



# Function to delete posts
@app.route("/delete", methods=["GET", "POST"])
def delete():
	# Connect to db
	cursor = connection.cursor(cursor_factory=psycopg2.extras.DictCursor)

	# Get user entered from form ID number
	ID = request.form['ID']

	# Delete the post
	cursor.execute("DELETE FROM posts WHERE id = %s", (ID,))
	connection.commit()

	return redirect(url_for('home'))



# Login page
@app.route("/login/", methods=["GET", "POST"])
def login():
	# Connect to db
	cursor = connection.cursor(cursor_factory=psycopg2.extras.DictCursor)

	# Check if "username" and "password" POST requests exist (user submitted form)
	if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
		username = request.form['username']
		password = request.form['password']
 
		# Check if account exists using MySQL
		cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
		# Fetch one record and return result
		account = cursor.fetchone()
 
		if account:
			password_rs = account['password']
			print(password_rs)
			# If account exists in users table in db
			if check_password_hash(password_rs, password):
				# Create session data, we can access this data in other routes
				session['loggedin'] = True
				session['id'] = account['id']
				session['username'] = account['username']
				session['firstname'] = account['firstname']
				# Redirect to home page
				return redirect(url_for('home'))
			else:
				# Account doesnt exist or username/password incorrect
				flash("Either your account doesn't exist or you have entered the wrong username or password.")
		else:
			# Account doesnt exist or username/password incorrect
			flash("Either your account doesn't exist or you have entered the wrong username or password.")

	return render_template("login.html")



# Register page
@app.route("/register", methods=["GET", "POST"])
def register():
	# Connect to db
	cursor = connection.cursor(cursor_factory=psycopg2.extras.DictCursor)

	sent = False
 
	# Check if all fields POST requests exist (user submitted form)
	if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'password2' in request.form and 'email' in request.form  and 'firstname' in request.form  and 'lastname' in request.form  and 'securityq1' in request.form  and 'securityq2' in request.form:
		# Create variables for easy access
		firstname = request.form['firstname']
		lastname = request.form['lastname']
		username = request.form['username']
		password = request.form['password']
		password2 = request.form['password2']
		email = request.form['email']
		securityq1 = request.form['securityq1']
		securityq2 = request.form['securityq2']
    
		_hashed_password = generate_password_hash(password)
 
		# Check if account exists using MySQL
		cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
		account = cursor.fetchone()
		# If account exists show error and validation checks
		if account:
			flash('Account already exists!')
		elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
			flash('Invalid email address!')
		elif not re.match(r'[A-Za-z0-9]+', username):
			flash('Username must contain only characters and numbers!')
		elif not re.match(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!#%*?&]{8,18}$', password):
			flash('Password must contain one uppercase letter, one lowercase letter, one number, one special character(@, $, !, %, *, #, ?, &), and must be 8-18 characters long.')
		elif password != password2:
			flash('Passwords do not match.')
		elif not username or not password or not email:
			flash('Please fill out the form!')
		else:
			# Account doesnt exist and the form data is valid, now insert new account into users table
			cursor.execute("INSERT INTO users (firstname, lastname, username, password, email, securityq1, securityq2) VALUES (%s,%s,%s,%s,%s,%s,%s)", (firstname, lastname, username, _hashed_password, email, securityq1, securityq2))
			connection.commit()
			sent = True
			flash('You have successfully registered!')
	elif request.method == 'POST':
		# Form is empty... (no POST data)
		flash('Please fill out the form!')
	# Show registration form with message (if any)
	return render_template('register.html', sent=sent)


#Forgot Password
@app.route("/forgotpassword", methods=["GET", "POST"])
def forgotpassword():
	global email_address
	global pass_recovery
	# Connect to db
	cursor = connection.cursor(cursor_factory=psycopg2.extras.DictCursor)

	# Check if "username" and "password" POST requests exist (user submitted form)
	if request.method == 'POST' and 'email' in request.form:
		email = request.form['email']
		
 
		# Check if account exists using MySQL
		cursor.execute('SELECT * FROM users WHERE email = %s', (email,))
		# Fetch one record and return result
		account = cursor.fetchone()
 
		if account:
			user_id = account['id']
			username = account['username']
			new_key = secrets.token_hex(16)
			pass_recovery[new_key] = [user_id,int(time.time())+60*60*24]

			msg = Message('Password Recovery - PB Scanner', sender =   email_address, recipients = [email])
			msg.body = "Hey " + username + ", you requested a password reset. Enter the following link to reset your password:\n http://127.0.0.1:5000/resetpassword?k="+new_key
			mail.send(msg)
			flash("Recovery email sent. Check your mailbox, don't forget to check in the spam folder, the email will expire in 24 hours!")
			
		else:
			# Account doesnt exist or username/password incorrect
			flash("No account associated with that email.")

	return render_template("forgotpassword.html")

#Forgot Username
@app.route("/forgotusername", methods=["GET", "POST"])
def forgotusername():
	global email_address
	# Connect to db
	cursor = connection.cursor(cursor_factory=psycopg2.extras.DictCursor)

	# Check if "username" and "password" POST requests exist (user submitted form)
	if request.method == 'POST' and 'email' in request.form:
		email = request.form['email']
		
 
		# Check if account exists using MySQL
		cursor.execute('SELECT * FROM users WHERE email = %s', (email,))
		# Fetch one record and return result
		account = cursor.fetchone()
 
		if account:
			username = account['username']
			msg = Message('Username Recovery - PB Scanner', sender =   email_address, recipients = [email])
			msg.body = "Hey there, you requested a username recovery. Your username is " + username
			mail.send(msg)
			flash("Recovery email sent. Check your mailbox, don't forget to check in the spam folder!")
			
		else:
			# Account doesnt exist or username/password incorrect
			flash("No account associated with that email.")

	return render_template("forgotusername.html")

#Reset Password
@app.route("/resetpassword", methods=["GET", "POST"])
def resetpassword():
	global pass_recovery
	# Connect to db
	cursor = connection.cursor(cursor_factory=psycopg2.extras.DictCursor)

	

	# Check if "username" and "password" POST requests exist (user submitted form)
	if request.method == 'POST' and 'new_password' in request.form and 'new_password2' in request.form and 'secret_key' in request.form:
		pass1 = request.form['new_password']
		pass2 = request.form['new_password2']
		secret_key = request.form['secret_key']
		if secret_key is None or secret_key not in pass_recovery:
			return "",400

		user_id = pass_recovery[secret_key][0]
		
		if int(time.time()) > pass_recovery[secret_key][1]:
			return "",400

		if pass1 != pass2:
			flash('Passwords do not match.')

		elif not re.match(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!#%*?&]{8,18}$', pass1):
			flash('Password must contain one uppercase letter, one lowercase letter, one number, one special character(@, $, !, %, *, #, ?, &), and must be 8-18 characters long.')
		else:
			_hashed_password = generate_password_hash(pass1)
			# Check if account exists using MySQL
			cursor.execute('UPDATE users SET password = %s WHERE id = %s', (_hashed_password,user_id))
			connection.commit()
			pass_recovery.pop(secret_key)
			flash('You have successfully reset your password!')

	else:
		secret_key = request.args.get('k',type = str)	
		if secret_key is None or secret_key not in pass_recovery:
			return "",400

		user_id = pass_recovery[secret_key]
		

	return render_template("resetpassword.html",skey = secret_key)


# Profile page
@app.route("/profile")
def profile():
	# Connect to db
	cursor = connection.cursor(cursor_factory=psycopg2.extras.DictCursor)
   
	# Check if user is loggedin
	if 'loggedin' in session:
		cursor.execute('SELECT * FROM users WHERE id = %s', [session['id']])
		account = cursor.fetchone()
		# Show the profile page with account info
		return render_template('profile.html', account=account, list=list)
	# User is not loggedin redirect to login page
	return redirect(url_for('login'))



@app.route('/logout')
def logout():
    # Remove session data, this will log the user out
   session.pop('loggedin', None)
   session.pop('id', None)
   session.pop('username', None)
   # Redirect to login page
   return redirect(url_for('login'))



# Main
if __name__ == '__main__':
	app.debug = True
	app.run()

