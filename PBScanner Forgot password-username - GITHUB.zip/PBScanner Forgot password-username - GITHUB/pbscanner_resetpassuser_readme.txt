README

1- Copy the new app.py in PBScanner, replace the old. Replace the html files
2- Activate the PBScanner environment
3- Activate the python virtual enviroment,  source bin/activate
4- pip install flask-mail
5- flask run

Known bugs:
-Register page doesnt check for email already registered
-Reset password page "Show password" checkbox dont work